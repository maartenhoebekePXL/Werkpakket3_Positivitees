<template>
  <nav class="navigation">
    <h1 class="navigation-heading">WanderTrails</h1>
    <ul class="navigation-links">
      <li><a href="#">Activiteiten</a></li>
      <li><a href="#">Routes</a></li>
      <li><a href="#">Account</a></li>
    </ul>
  </nav>
</template>
<script>
export default {}
</script>
<style></style>
