<script></script>

<template>
  <RouterView></RouterView>
</template>

<style></style>
